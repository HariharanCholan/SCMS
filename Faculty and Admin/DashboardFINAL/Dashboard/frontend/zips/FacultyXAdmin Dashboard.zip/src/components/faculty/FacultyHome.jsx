
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Calendar, Clock, MapPin, Users, Building, CheckCircle, XCircle, AlertTriangle, Edit } from 'lucide-react';

const FacultyHome = () => {
  const [classrooms, setClassrooms] = useLocalStorage('classrooms', []);
  const [bookings, setBookings] = useLocalStorage('bookings', []);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    roomId: '',
    subject: '',
    timeSlot: '',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const timeSlots = [
    '8:00 - 8:45',
    '8:45 - 9:30',
    '9:45 - 10:30',
    '10:30 - 11:15',
    '12:00 - 12:45',
    '12:45 - 1:30',
    '1:30 - 2:15',
    '2:15 - 3:00'
  ];

  const statusOptions = [
    { value: 'available', label: 'Available', color: 'text-green-400', icon: CheckCircle },
    { value: 'occupied', label: 'Occupied', color: 'text-red-400', icon: XCircle },
    { value: 'maintenance', label: 'Maintenance', color: 'text-yellow-400', icon: AlertTriangle }
  ];

  const resetForm = () => {
    setFormData({
      roomId: '',
      subject: '',
      timeSlot: '',
      date: new Date().toISOString().split('T')[0],
      notes: ''
    });
  };

  const handleBooking = (e) => {
    e.preventDefault();
    
    if (!formData.roomId || !formData.subject || !formData.timeSlot) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const room = classrooms.find(r => r.id === formData.roomId);
    if (!room) {
      toast({
        title: "Error",
        description: "Selected room not found",
        variant: "destructive"
      });
      return;
    }

    if (room.status !== 'available') {
      toast({
        title: "Error",
        description: "Room is not available for booking",
        variant: "destructive"
      });
      return;
    }

    // Check for conflicts
    const conflict = bookings.find(booking => 
      booking.roomId === formData.roomId && 
      booking.date === formData.date && 
      booking.timeSlot === formData.timeSlot
    );

    if (conflict) {
      toast({
        title: "Error",
        description: "This time slot is already booked",
        variant: "destructive"
      });
      return;
    }

    const booking = {
      id: Date.now().toString(),
      ...formData,
      roomName: room.name,
      roomType: room.type,
      faculty: 'Current Faculty', // In real app, this would come from auth
      createdAt: new Date().toISOString()
    };

    setBookings(prev => [...prev, booking]);
    toast({
      title: "Success",
      description: "Room booked successfully"
    });

    resetForm();
    setIsDialogOpen(false);
  };

  const handleStatusUpdate = (roomId, newStatus) => {
    setClassrooms(prev => prev.map(room => 
      room.id === roomId 
        ? { ...room, status: newStatus, updatedAt: new Date().toISOString() }
        : room
    ));
    
    toast({
      title: "Success",
      description: "Room status updated successfully"
    });
    
    setIsStatusDialogOpen(false);
    setSelectedRoom(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'available':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'occupied':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'maintenance':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getStatusIcon = (status) => {
    const option = statusOptions.find(opt => opt.value === status);
    if (option) {
      const Icon = option.icon;
      return <Icon className={`h-4 w-4 ${option.color}`} />;
    }
    return <Building className="h-4 w-4 text-gray-400" />;
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'auditorium':
        return <Users className="h-5 w-5" />;
      case 'lab':
        return <MapPin className="h-5 w-5" />;
      default:
        return <Building className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex justify-between items-center"
      >
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Faculty Dashboard</h1>
          <p className="text-gray-400">Manage room bookings and update facility status</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={resetForm}
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:opacity-90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Book Room
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-effect border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>Book a Classroom</DialogTitle>
              <DialogDescription className="text-gray-400">
                Reserve a classroom for your next session
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleBooking} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="roomId">Classroom</Label>
                <Select value={formData.roomId} onValueChange={(value) => setFormData(prev => ({ ...prev, roomId: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a classroom" />
                  </SelectTrigger>
                  <SelectContent>
                    {classrooms.filter(room => room.status === 'available').map(room => (
                      <SelectItem key={room.id} value={room.id}>
                        {room.name} ({room.type}) - {room.capacity} seats
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject/Purpose</Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="Enter subject or purpose"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="timeSlot">Time Slot</Label>
                <Select value={formData.timeSlot} onValueChange={(value) => setFormData(prev => ({ ...prev, timeSlot: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map(slot => (
                      <SelectItem key={slot} value={slot}>
                        {slot}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Input
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Additional notes"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-green-600 to-teal-600">
                  Book Room
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      {/* Room Status Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <h2 className="text-2xl font-semibold text-white mb-6 flex items-center">
          <Building className="h-6 w-6 mr-2 text-green-400" />
          Classroom Status
        </h2>
        
        {classrooms.length === 0 ? (
          <Card className="glass-effect border-gray-700">
            <CardContent className="text-center py-12">
              <Building className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 text-lg mb-2">No classrooms available</p>
              <p className="text-gray-500">Contact admin to add classrooms</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classrooms.map((room, index) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="glass-effect border-gray-700 card-hover h-full">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-600 to-teal-600 flex items-center justify-center">
                          {getTypeIcon(room.type)}
                        </div>
                        <div>
                          <CardTitle className="text-white text-lg">{room.name}</CardTitle>
                          <CardDescription className="text-gray-400 capitalize">
                            {room.type}
                          </CardDescription>
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded-full border text-xs font-medium ${getStatusColor(room.status)}`}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(room.status)}
                          <span className="capitalize">{room.status}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Capacity</span>
                        <span className="text-white font-medium">{room.capacity} seats</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Location</span>
                        <span className="text-white font-medium">{room.location}</span>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => {
                        setSelectedRoom(room);
                        setIsStatusDialogOpen(true);
                      }}
                      variant="outline"
                      className="w-full border-gray-600 text-gray-300 hover:text-white hover:bg-gray-700"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Update Status
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {/* My Bookings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <Card className="glass-effect border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-400" />
              My Bookings
            </CardTitle>
            <CardDescription className="text-gray-400">
              Your upcoming classroom reservations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {bookings.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                <p className="text-gray-400">No bookings yet</p>
                <p className="text-gray-500 text-sm">Book your first classroom to get started</p>
              </div>
            ) : (
              <div className="space-y-4">
                {bookings.slice(0, 5).map((booking, index) => (
                  <motion.div
                    key={booking.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="glass-effect border border-gray-600 rounded-lg p-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4 mb-2">
                          <h3 className="text-lg font-semibold text-white">{booking.subject}</h3>
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">
                            {booking.roomType}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-400">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-2" />
                            {booking.roomName}
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-2" />
                            {booking.timeSlot}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-2" />
                            {new Date(booking.date).toLocaleDateString()}
                          </div>
                        </div>
                        {booking.notes && (
                          <p className="text-gray-500 text-sm mt-2">{booking.notes}</p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Status Update Dialog */}
      <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
        <DialogContent className="glass-effect border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Update Room Status</DialogTitle>
            <DialogDescription className="text-gray-400">
              Change the status of {selectedRoom?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {statusOptions.map((option) => {
              const Icon = option.icon;
              return (
                <Button
                  key={option.value}
                  onClick={() => handleStatusUpdate(selectedRoom?.id, option.value)}
                  variant="outline"
                  className={`w-full justify-start border-gray-600 hover:bg-gray-700 ${
                    selectedRoom?.status === option.value ? 'border-blue-500 bg-blue-500/10' : ''
                  }`}
                >
                  <Icon className={`h-4 w-4 mr-3 ${option.color}`} />
                  <span className="text-white">{option.label}</span>
                </Button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FacultyHome;
