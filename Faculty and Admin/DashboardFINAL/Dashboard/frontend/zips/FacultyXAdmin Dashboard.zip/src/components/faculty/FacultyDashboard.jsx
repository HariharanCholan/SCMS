
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import FacultyLayout from '@/components/faculty/FacultyLayout';
import FacultyHome from '@/components/faculty/FacultyHome';
import StudentInsights from '@/components/faculty/StudentInsights';
import Attendance from '@/components/faculty/Attendance';
import QuizGenerator from '@/components/faculty/QuizGenerator';
import EmergencyAlerts from '@/components/faculty/EmergencyAlerts';
import Settings from '@/components/faculty/Settings';

const FacultyDashboard = () => {
  return (
    <FacultyLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/faculty/home" replace />} />
        <Route path="/home" element={<FacultyHome />} />
        <Route path="/student-insights" element={<StudentInsights />} />
        <Route path="/attendance" element={<Attendance />} />
        <Route path="/quiz-generator" element={<QuizGenerator />} />
        <Route path="/emergency-alerts" element={<EmergencyAlerts />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </FacultyLayout>
  );
};

export default FacultyDashboard;
