
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Calendar, Clock, MapPin, Users, Trash2, Edit } from 'lucide-react';

const TrackResources = () => {
  const [classrooms] = useLocalStorage('classrooms', []);
  const [schedule, setSchedule] = useLocalStorage('schedule', []);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    roomId: '',
    subject: '',
    faculty: '',
    timeSlot: '',
    date: new Date().toISOString().split('T')[0],
    duration: '45' // Default 45 minutes
  });

  const timeSlots = [
    '8:00 - 8:45',
    '8:45 - 9:30',
    '9:45 - 10:30',
    '10:30 - 11:15',
    '12:00 - 12:45',
    '12:45 - 1:30',
    '1:30 - 2:15',
    '2:15 - 3:00'
  ];

  const resetForm = () => {
    setFormData({
      roomId: '',
      subject: '',
      faculty: '',
      timeSlot: '',
      date: new Date().toISOString().split('T')[0],
      duration: '45'
    });
    setEditingItem(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.roomId || !formData.subject || !formData.faculty || !formData.timeSlot) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const room = classrooms.find(r => r.id === formData.roomId);
    if (!room) {
      toast({
        title: "Error",
        description: "Selected room not found",
        variant: "destructive"
      });
      return;
    }

    const scheduleItem = {
      id: editingItem ? editingItem.id : Date.now().toString(),
      ...formData,
      roomName: room.name,
      roomType: room.type,
      createdAt: editingItem ? editingItem.createdAt : new Date().toISOString()
    };

    if (editingItem) {
      setSchedule(prev => prev.map(item => item.id === editingItem.id ? scheduleItem : item));
      toast({
        title: "Success",
        description: "Schedule updated successfully"
      });
    } else {
      setSchedule(prev => [...prev, scheduleItem]);
      toast({
        title: "Success",
        description: "Schedule added successfully"
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      roomId: item.roomId,
      subject: item.subject,
      faculty: item.faculty,
      timeSlot: item.timeSlot,
      date: item.date,
      duration: item.duration
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    setSchedule(prev => prev.filter(item => item.id !== id));
    toast({
      title: "Success",
      description: "Schedule item deleted successfully"
    });
  };

  const calculateTotalHours = () => {
    return schedule.reduce((total, item) => {
      return total + (parseInt(item.duration) / 60);
    }, 0);
  };

  const getResourceStats = () => {
    const stats = {
      total: 0,
      classroom: 0,
      auditorium: 0,
      lab: 0
    };

    schedule.forEach(item => {
      const hours = parseInt(item.duration) / 60;
      stats.total += hours;
      
      switch (item.roomType) {
        case 'classroom':
          stats.classroom += hours;
          break;
        case 'auditorium':
          stats.auditorium += hours;
          break;
        case 'lab':
          stats.lab += hours;
          break;
      }
    });

    return stats;
  };

  const stats = getResourceStats();

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex justify-between items-center"
      >
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Track Resources</h1>
          <p className="text-gray-400">Monitor and manage classroom schedules and resource utilization</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={resetForm}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-effect border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Edit Schedule' : 'Add New Schedule'}</DialogTitle>
              <DialogDescription className="text-gray-400">
                {editingItem ? 'Update the schedule details' : 'Create a new schedule entry for resource tracking'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="roomId">Classroom</Label>
                <Select value={formData.roomId} onValueChange={(value) => setFormData(prev => ({ ...prev, roomId: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a classroom" />
                  </SelectTrigger>
                  <SelectContent>
                    {classrooms.map(room => (
                      <SelectItem key={room.id} value={room.id}>
                        {room.name} ({room.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="Enter subject name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="faculty">Faculty</Label>
                <Input
                  id="faculty"
                  value={formData.faculty}
                  onChange={(e) => setFormData(prev => ({ ...prev, faculty: e.target.value }))}
                  placeholder="Enter faculty name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="timeSlot">Time Slot</Label>
                <Select value={formData.timeSlot} onValueChange={(value) => setFormData(prev => ({ ...prev, timeSlot: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map(slot => (
                      <SelectItem key={slot} value={slot}>
                        {slot}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600">
                  {editingItem ? 'Update' : 'Add'} Schedule
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      {/* Resource Statistics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="glass-effect border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">Total Hours</p>
                  <p className="text-3xl font-bold text-white">{stats.total.toFixed(1)}h</p>
                </div>
                <Clock className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">Classroom Hours</p>
                  <p className="text-3xl font-bold text-white">{stats.classroom.toFixed(1)}h</p>
                </div>
                <Users className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">Auditorium Hours</p>
                  <p className="text-3xl font-bold text-white">{stats.auditorium.toFixed(1)}h</p>
                </div>
                <MapPin className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">Lab Hours</p>
                  <p className="text-3xl font-bold text-white">{stats.lab.toFixed(1)}h</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Schedule List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <Card className="glass-effect border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Current Schedule</CardTitle>
            <CardDescription className="text-gray-400">
              All scheduled classes and resource allocations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {schedule.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                <p className="text-gray-400">No schedules added yet</p>
                <p className="text-gray-500 text-sm">Add your first schedule to start tracking resources</p>
              </div>
            ) : (
              <div className="space-y-4">
                {schedule.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="glass-effect border border-gray-600 rounded-lg p-4 card-hover"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4 mb-2">
                          <h3 className="text-lg font-semibold text-white">{item.subject}</h3>
                          <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs">
                            {item.roomType}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-400">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-2" />
                            {item.roomName}
                          </div>
                          <div className="flex items-center">
                            <Users className="h-4 w-4 mr-2" />
                            {item.faculty}
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-2" />
                            {item.timeSlot}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-2" />
                            {new Date(item.date).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(item)}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(item.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default TrackResources;
