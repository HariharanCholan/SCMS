import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Plus, Calendar, Clock, MapPin, Users, Trash2, Edit } from 'lucide-react';
import ScheduleForm from '@/components/admin/ScheduleForm';
import ScheduleList from '@/components/admin/ScheduleList';
import ResourceStats from '@/components/admin/ResourceStats';

const TrackResources = () => {
  const [classrooms] = useLocalStorage('classrooms', []);
  const [schedule, setSchedule] = useLocalStorage('schedule', []);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);

  const resetFormState = () => {
    setEditingItem(null);
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex justify-between items-center"
      >
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Track Resources</h1>
          <p className="text-gray-400">Monitor and manage classroom schedules and resource utilization</p>
        </div>
        
        <Button 
          onClick={() => { resetFormState(); setIsDialogOpen(true); }}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Schedule
        </Button>
      </motion.div>

      <ScheduleForm
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        editingItem={editingItem}
        setEditingItem={setEditingItem}
        classrooms={classrooms}
        schedule={schedule}
        setSchedule={setSchedule}
      />

      <ResourceStats schedule={schedule} />

      <ScheduleList
        schedule={schedule}
        setSchedule={setSchedule}
        setEditingItem={setEditingItem}
        setIsDialogOpen={setIsDialogOpen}
      />
    </div>
  );
};

export default TrackResources;