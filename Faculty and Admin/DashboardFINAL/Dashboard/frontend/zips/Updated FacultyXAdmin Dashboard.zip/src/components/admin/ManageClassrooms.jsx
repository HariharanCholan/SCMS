import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Building, Users, MapPin, Trash2, Edit, AlertTriangle } from 'lucide-react';

const ManageClassrooms = () => {
  const [classrooms, setClassrooms] = useLocalStorage('classrooms', []);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    type: '',
    capacity: '',
    location: '',
    status: 'available'
  });

  const roomTypes = [
    { value: 'classroom', label: 'Classroom' },
    { value: 'auditorium', label: 'Auditorium' },
    { value: 'lab', label: 'Laboratory' },
    { value: 'conference', label: 'Conference Room' }
  ];

  const statusOptions = [
    { value: 'available', label: 'Available', color: 'text-green-400' },
    { value: 'occupied', label: 'Occupied', color: 'text-red-400' },
    { value: 'maintenance', label: 'Maintenance', color: 'text-yellow-400' }
  ];

  const resetForm = () => {
    setFormData({
      name: '',
      type: '',
      capacity: '',
      location: '',
      status: 'available'
    });
    setEditingRoom(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.type || !formData.capacity || !formData.location) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const classroom = {
      id: editingRoom ? editingRoom.id : Date.now().toString(),
      ...formData,
      capacity: parseInt(formData.capacity),
      createdAt: editingRoom ? editingRoom.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (editingRoom) {
      setClassrooms(prev => prev.map(room => room.id === editingRoom.id ? classroom : room));
      toast({
        title: "Success",
        description: "Classroom updated successfully"
      });
    } else {
      setClassrooms(prev => [...prev, classroom]);
      toast({
        title: "Success",
        description: "Classroom created successfully"
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (room) => {
    setEditingRoom(room);
    setFormData({
      name: room.name,
      type: room.type,
      capacity: room.capacity.toString(),
      location: room.location,
      status: room.status
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    setClassrooms(prev => prev.filter(room => room.id !== id));
    toast({
      title: "Success",
      description: "Classroom deleted successfully"
    });
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'available':
        return <Building className="h-4 w-4 text-green-400" />;
      case 'occupied':
        return <Users className="h-4 w-4 text-red-400" />;
      case 'maintenance':
        return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
      default:
        return <Building className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'available':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'occupied':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'maintenance':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'auditorium':
        return <Users className="h-5 w-5" />;
      case 'lab':
        return <MapPin className="h-5 w-5" />;
      default:
        return <Building className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex justify-between items-center"
      >
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Manage Classrooms</h1>
          <p className="text-gray-400">Create, edit, and manage classroom facilities</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={resetForm}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Classroom
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-effect border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>{editingRoom ? 'Edit Classroom' : 'Add New Classroom'}</DialogTitle>
              <DialogDescription className="text-gray-400">
                {editingRoom ? 'Update classroom details' : 'Create a new classroom facility'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Classroom Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Room 101, Main Auditorium"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Room Type</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select room type" />
                  </SelectTrigger>
                  <SelectContent>
                    {roomTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="capacity">Capacity</Label>
                <Input
                  id="capacity"
                  type="number"
                  value={formData.capacity}
                  onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
                  placeholder="Number of seats"
                  min="1"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="e.g., Building A, Floor 2"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map(status => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600">
                  {editingRoom ? 'Update' : 'Create'} Classroom
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        {classrooms.length === 0 ? (
          <Card className="glass-effect border-gray-700">
            <CardContent className="text-center py-12">
              <Building className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 text-lg mb-2">No classrooms added yet</p>
              <p className="text-gray-500">Create your first classroom to get started</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classrooms.map((room, index) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="glass-effect border-gray-700 card-hover h-full">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                          {getTypeIcon(room.type)}
                        </div>
                        <div>
                          <CardTitle className="text-white text-lg">{room.name}</CardTitle>
                          <CardDescription className="text-gray-400 capitalize">
                            {room.type}
                          </CardDescription>
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded-full border text-xs font-medium ${getStatusColor(room.status)}`}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(room.status)}
                          <span className="capitalize">{room.status}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Capacity</span>
                        <span className="text-white font-medium">{room.capacity} seats</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Location</span>
                        <span className="text-white font-medium">{room.location}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(room)}
                        className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(room.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {classrooms.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card className="glass-effect border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Classroom Summary</CardTitle>
              <CardDescription className="text-gray-400">
                Overview of all classroom facilities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-white">{classrooms.length}</p>
                  <p className="text-gray-400 text-sm">Total Rooms</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-400">
                    {classrooms.filter(r => r.status === 'available').length}
                  </p>
                  <p className="text-gray-400 text-sm">Available</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-red-400">
                    {classrooms.filter(r => r.status === 'occupied').length}
                  </p>
                  <p className="text-gray-400 text-sm">Occupied</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-yellow-400">
                    {classrooms.filter(r => r.status === 'maintenance').length}
                  </p>
                  <p className="text-gray-400 text-sm">Maintenance</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
};

export default ManageClassrooms;