import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';

const timeSlots = [
  '8:00 - 8:45',
  '8:45 - 9:30',
  '9:45 - 10:30',
  '10:30 - 11:15',
  '12:00 - 12:45',
  '12:45 - 1:30',
  '1:30 - 2:15',
  '2:15 - 3:00'
];

const ScheduleForm = ({ isOpen, setIsOpen, editingItem, setEditingItem, classrooms, schedule, setSchedule }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    roomId: '',
    subject: '',
    faculty: '',
    timeSlot: '',
    date: new Date().toISOString().split('T')[0],
    duration: '45'
  });

  useEffect(() => {
    if (editingItem) {
      setFormData({
        roomId: editingItem.roomId,
        subject: editingItem.subject,
        faculty: editingItem.faculty,
        timeSlot: editingItem.timeSlot,
        date: editingItem.date,
        duration: editingItem.duration
      });
    } else {
      resetForm();
    }
  }, [editingItem, isOpen]);

  const resetForm = () => {
    setFormData({
      roomId: '',
      subject: '',
      faculty: '',
      timeSlot: '',
      date: new Date().toISOString().split('T')[0],
      duration: '45'
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.roomId || !formData.subject || !formData.faculty || !formData.timeSlot) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const room = classrooms.find(r => r.id === formData.roomId);
    if (!room) {
      toast({
        title: "Error",
        description: "Selected room not found",
        variant: "destructive"
      });
      return;
    }

    const scheduleItem = {
      id: editingItem ? editingItem.id : Date.now().toString(),
      ...formData,
      roomName: room.name,
      roomType: room.type,
      createdAt: editingItem ? editingItem.createdAt : new Date().toISOString()
    };

    if (editingItem) {
      setSchedule(prev => prev.map(item => item.id === editingItem.id ? scheduleItem : item));
      toast({
        title: "Success",
        description: "Schedule updated successfully"
      });
    } else {
      setSchedule(prev => [...prev, scheduleItem]);
      toast({
        title: "Success",
        description: "Schedule added successfully"
      });
    }

    resetForm();
    setEditingItem(null);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      setIsOpen(open);
      if (!open) setEditingItem(null);
    }}>
      <DialogContent className="glass-effect border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle>{editingItem ? 'Edit Schedule' : 'Add New Schedule'}</DialogTitle>
          <DialogDescription className="text-gray-400">
            {editingItem ? 'Update the schedule details' : 'Create a new schedule entry for resource tracking'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="roomId">Classroom</Label>
            <Select value={formData.roomId} onValueChange={(value) => setFormData(prev => ({ ...prev, roomId: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select a classroom" />
              </SelectTrigger>
              <SelectContent>
                {classrooms.map(room => (
                  <SelectItem key={room.id} value={room.id}>
                    {room.name} ({room.type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
              placeholder="Enter subject name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="faculty">Faculty</Label>
            <Input
              id="faculty"
              value={formData.faculty}
              onChange={(e) => setFormData(prev => ({ ...prev, faculty: e.target.value }))}
              placeholder="Enter faculty name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="timeSlot">Time Slot</Label>
            <Select value={formData.timeSlot} onValueChange={(value) => setFormData(prev => ({ ...prev, timeSlot: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select time slot" />
              </SelectTrigger>
              <SelectContent>
                {timeSlots.map(slot => (
                  <SelectItem key={slot} value={slot}>
                    {slot}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => { setIsOpen(false); setEditingItem(null); }}>
              Cancel
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600">
              {editingItem ? 'Update' : 'Add'} Schedule
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ScheduleForm;